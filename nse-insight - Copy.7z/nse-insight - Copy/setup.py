import setuptools

setuptools.setup(
    name = "nse_history_data",
    version = "0.0.1",
    author = "Rupesh Gupta",
    description = "To download the data from nse site",
    packages = [
        "nse_history"
    ],
    install_requires = [
        "nsepy",
        "nsetools",
        "pandas",
        "setuptools",
        "wheel"
    ]

)