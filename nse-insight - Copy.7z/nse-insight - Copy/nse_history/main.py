from nse_history import nse_history

# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    path = "C:\\Users\\171575\\PycharmProjects\\nse-insight"
    nse_history(path)

# See PyCharm help at https://www.jetbrains.com/help/pycharm/
